import { Worker, QueueScheduler } from 'bullmq'
import IORedis from 'ioredis'
import { createRenderForProvider } from './services/videoProvider'
import { uploadFileToS3 } from './lib/s3Uploader'
import { updateJobStatus } from './services/videoAdapter'
import fs from 'fs'

const connection = new IORedis(process.env.REDIS_URL || 'redis://127.0.0.1:6379')
const queueName = process.env.VIDEO_QUEUE_NAME || 'video-jobs'
new QueueScheduler(queueName, { connection })

const worker = new Worker(queueName, async job => {
  const data = job.data
  console.log('Worker: processing job', job.id, data)
  try {
    updateJobStatus(data.jobId, { status: 'running' })
    const outPath = await createRenderForProvider(data)
    if (!outPath || !fs.existsSync(outPath)) {
      throw new Error('Provider did not produce output file: ' + outPath)
    }
    const key = `${data.jobId}.mp4`
    const publicUrl = await uploadFileToS3(outPath, key)
    updateJobStatus(data.jobId, { status: 'done', resultUrl: publicUrl, finishedAt: Date.now() })
    console.log('Worker: uploaded result to', publicUrl)
    return { status: 'done', resultUrl: publicUrl }
  } catch (err) {
    console.error('Worker error', err)
    updateJobStatus(data.jobId, { status: 'failed', error: String(err) })
    throw err
  }
}, { connection })

worker.on('failed', (job, err) => {
  console.error('Job failed', job?.id, err)
})
worker.on('completed', (job, returnval) => {
  console.log('Job completed', job?.id, returnval)
})
