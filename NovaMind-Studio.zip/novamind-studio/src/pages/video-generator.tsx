import { useState } from 'react'
import axios from 'axios'

const MAX_DURATION = 40 * 60 // 40 minutes in seconds

export default function VideoGenerator(){
  const [script, setScript] = useState('')
  const [duration, setDuration] = useState(120)
  const [status, setStatus] = useState<string | null>(null)
  const [jobId, setJobId] = useState<string | null>(null)
  const [model, setModel] = useState('veo3')
  const [style, setStyle] = useState('cinematic')
  const [quality, setQuality] = useState('standard')
  const [voice, setVoice] = useState('alloy')
  const [error, setError] = useState<string | null>(null)
  const [isSubmitting, setIsSubmitting] = useState(false)

  const styles = [
    { value: 'cinematic', label: 'Cinematic' },
    { value: 'historical', label: 'Historical / Period' },
    { value: 'cartoon', label: 'Cartoon' },
    { value: 'anime', label: 'Anime' },
    { value: 'documentary', label: 'Documentary' },
    { value: 'realistic', label: 'Photorealistic' }
  ]

  const qualities = [
    { value: 'preview', label: 'Fast Preview (low-res)' },
    { value: 'standard', label: 'Standard (720p)' },
    { value: 'hd', label: 'HD (1080p)' },
    { value: '4k', label: 'Ultra HD (4K)' }
  ]

  const handleGenerate = async () => {
    setError(null)
    if (!script || script.trim().length < 10) {
      setError('Please enter a script or story (at least 10 characters).')
      return
    }
    if (duration <= 0 || duration > MAX_DURATION) {
      setError('Duration must be between 1 second and 40 minutes.')
      return
    }
    setIsSubmitting(true)
    setStatus('queued')
    try {
      const res = await axios.post('/api/generate/video', { script, duration, model, style, quality, voice })
      setJobId(res.data.jobId)
      setStatus('started')
      // Polling example (simplified)
      const poll = setInterval(async () => {
        const r = await axios.get(`/api/generate/video?jobId=${res.data.jobId}`)
        if (r.data.status === 'done') {
          clearInterval(poll)
          setStatus('done')
          setIsSubmitting(false)
        } else {
          setStatus(r.data.status)
        }
      }, 3000)
    } catch (err: any) {
      console.error(err)
      setStatus('error')
      setError(err?.response?.data?.error || 'Generation failed')
      setIsSubmitting(false)
    }
  }

  return (
    <div>
      <h2 className="text-2xl mb-4">AI Video Generator</h2>
      <p className="mb-3 text-sm text-white/70">Create professional AI videos. Max duration: 40 minutes. Choose a style, quality and voice.</p>
      <textarea value={script} onChange={(e)=>setScript(e.target.value)} placeholder="Write your story or script..." className="w-full h-40 p-3 mb-3" />
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-3">
        <div className="flex items-center gap-3">
          <label>Duration (seconds)</label>
          <input type="number" value={duration} onChange={(e)=>setDuration(Number(e.target.value))} className="border p-1 w-32" />
          <span className="text-sm text-white/60"> (max 2400 s = 40 min)</span>
        </div>
        <div className="flex items-center gap-3">
          <label>Model</label>
          <select value={model} onChange={(e)=>setModel(e.target.value)} className="border p-1">
            <option value="veo3">Veo 3</option>
            <option value="sora2">Sora 2</option>
            <option value="hybrid">Hybrid (Veo+Sora)</option>
          </select>
        </div>

        <div className="flex items-center gap-3">
          <label>Style</label>
          <select value={style} onChange={(e)=>setStyle(e.target.value)} className="border p-1">
            {styles.map(s => <option key={s.value} value={s.value}>{s.label}</option>)}
          </select>
        </div>

        <div className="flex items-center gap-3">
          <label>Quality</label>
          <select value={quality} onChange={(e)=>setQuality(e.target.value)} className="border p-1">
            {qualities.map(q => <option key={q.value} value={q.value}>{q.label}</option>)}
          </select>
        </div>

        <div className="flex items-center gap-3">
          <label>Voice</label>
          <select value={voice} onChange={(e)=>setVoice(e.target.value)} className="border p-1">
            <option value="alloy">Alloy (Neutral)</option>
            <option value="emma">Emma (Female)</option>
            <option value="mason">Mason (Male)</option>
            <option value="auto">Auto-select</option>
          </select>
        </div>

      </div>

      <div className="flex items-center gap-3 mb-3">
        <button onClick={handleGenerate} disabled={isSubmitting} className="px-4 py-2 bg-green-600 rounded">
          {isSubmitting ? 'Generating...' : 'Generate'}
        </button>
        <button onClick={()=>{ setScript(''); setDuration(120); setStyle('cinematic'); setQuality('standard') }} className="px-4 py-2 border rounded">Reset</button>
      </div>

      {error && <div className="mb-3 text-red-400">{error}</div>}

      <div>
        <strong>Status:</strong> {status ?? 'idle'} {jobId && <span> | Job: {jobId}</span>}
      </div>
    </div>
