import { useState } from 'react'
import axios from 'axios'

export default function TTSPage(){
  const [text, setText] = useState('')
  const [audioUrl, setAudioUrl] = useState<string | null>(null)

  const generate = async () => {
    const res = await axios.post('/api/generate/tts', { text, voice: 'alloy' })
    setAudioUrl(res.data.audioUrl)
  }

  return (
    <div>
      <h2 className="text-2xl mb-4">Text-to-Speech</h2>
      <textarea value={text} onChange={(e)=>setText(e.target.value)} className="w-full h-36 p-2" />
      <div className="mt-2">
        <button onClick={generate} className="px-3 py-1 bg-indigo-600 rounded">Generate Voice</button>
      </div>
      {audioUrl && (
        <div className="mt-4">
          <audio controls src={audioUrl}></audio>
        </div>
      )}
    </div>
