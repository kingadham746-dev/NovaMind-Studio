export default function Dashboard(){
  return (
    <div>
      <h2 className="text-2xl mb-4">Dashboard</h2>
      <p>Recent projects, credits, and quick actions will appear here.</p>
    </div>
  )
}
