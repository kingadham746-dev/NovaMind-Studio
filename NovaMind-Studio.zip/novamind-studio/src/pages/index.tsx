import Link from 'next/link'

export default function Home(){
  return (
    <div>
      <h2 className="text-3xl mb-4">Welcome to NovaMind Studio</h2>
      <p className="mb-6">Create AI videos using Veo 3, Sora 2, realistic TTS and an integrated assistant.</p>
      <div className="flex gap-4">
        <Link href="/video-generator"><a className="px-4 py-2 bg-blue-600 rounded">Create Video</a></Link>
        <Link href="/chatbot"><a className="px-4 py-2 border rounded">Ask VisionBot</a></Link>
      </div>
    </div>
  )
}
