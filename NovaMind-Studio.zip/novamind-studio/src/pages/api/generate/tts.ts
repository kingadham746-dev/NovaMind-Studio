import type { NextApiRequest, NextApiResponse } from 'next'
import { generateTTS } from '@/services/ttsService'

export default async function handler(req: NextApiRequest, res: NextApiResponse){
  if (req.method !== 'POST') return res.status(405).end()
  const { text, voice } = req.body
  try {
    const audioUrl = await generateTTS({ text, voice })
    res.status(200).json({ audioUrl })
  } catch (err) {
    console.error(err)
    res.status(500).json({ error: 'tts_failed' })
  }
}
