import type { NextApiRequest, NextApiResponse } from 'next'
import { createVideoJob, getJobStatus } from '@/services/videoAdapter'

const MAX_DURATION = 40 * 60 // seconds

export default async function handler(req: NextApiRequest, res: NextApiResponse){
  if (req.method === 'POST') {
    const { script, duration=60, model='veo3', style='cinematic', quality='standard', voice='alloy' } = req.body

    // basic validation
    if (!script || typeof script !== 'string' || script.trim().length < 10) {
      return res.status(400).json({ error: 'invalid_script' })
    }
    if (typeof duration !== 'number' || duration <= 0 || duration > MAX_DURATION) {
      return res.status(400).json({ error: 'invalid_duration', message: 'Duration must be 1..2400 seconds (max 40 minutes)' })
    }

    try {
      const job = await createVideoJob({ script, duration, model, style, quality, voice })
      return res.status(200).json({ jobId: job.id })
    } catch (err) {
      console.error(err)
      return res.status(500).json({ error: 'generation_failed' })
    }
  } else if (req.method === 'GET') {
    const jobId = String(req.query.jobId)
    const status = await getJobStatus(jobId)
    return res.status(200).json(status)
  }
  res.setHeader('Allow', 'POST, GET'); res.status(405).end('Method Not Allowed')
}
