import type { NextApiRequest, NextApiResponse } from 'next'
import { askGemini } from '@/services/geminiService'

export default async function handler(req: NextApiRequest, res: NextApiResponse){
  if (req.method !== 'POST') return res.status(405).end()
  const { prompt } = req.body
  try {
    const answer = await askGemini(prompt)
    res.status(200).json({ answer })
  } catch (err) {
    console.error(err)
    res.status(500).json({ error: 'chat_failed' })
  }
}
