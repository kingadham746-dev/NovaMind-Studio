import { useState } from 'react'
import axios from 'axios'

export default function Chatbot(){
  const [query, setQuery] = useState('')
  const [history, setHistory] = useState<{q:string, a:string}[]>([])

  const send = async () => {
    const res = await axios.post('/api/chatbot/message', { prompt: query })
    setHistory(h => [...h, { q: query, a: res.data.answer }])
    setQuery('')
  }

  return (
    <div>
      <h2 className="text-2xl mb-4">VisionBot — AI Assistant</h2>
      <div className="mb-3">
        <textarea value={query} onChange={(e)=>setQuery(e.target.value)} className="w-full h-24 p-2" />
        <div className="flex gap-2 mt-2">
          <button onClick={send} className="px-3 py-1 bg-blue-600 rounded">Ask</button>
        </div>
      </div>
      <div>
        {history.map((item, idx) => (
          <div key={idx} className="mb-2 p-2 border rounded bg-white/3">
            <div className="text-sm text-white/70">You: {item.q}</div>
            <div className="mt-1">Bot: {item.a}</div>
          </div>
        ))}
      </div>
    </div>
