import { S3Client, PutObjectCommand } from '@aws-sdk/client-s3'
import fs from 'fs'
import path from 'path'

const REGION = process.env.AWS_REGION || 'us-east-1'
const BUCKET = process.env.S3_BUCKET_NAME

if (!BUCKET) {
  console.warn('S3_BUCKET_NAME not set; S3 uploads will fail')
}

const s3 = new S3Client({ region: REGION })

export async function uploadFileToS3(localPath: string, key?: string): Promise<string> {
  if (!BUCKET) throw new Error('S3_BUCKET_NAME is not configured')
  const body = fs.readFileSync(localPath)
  const filename = key || path.basename(localPath)
  const cmd = new PutObjectCommand({
    Bucket: BUCKET,
    Key: filename,
    Body: body,
    ACL: 'public-read'
  })
  await s3.send(cmd)
  return `https://${BUCKET}.s3.${REGION}.amazonaws.com/${filename}`
}
