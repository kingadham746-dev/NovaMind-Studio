import React from 'react'
import ThemeToggle from './ThemeToggle'
import LoginButton from './LoginButton'

export default function Header(){
  return (
    <header className="bg-white/5 border-b border-white/5 p-4 flex justify-end items-center gap-4">
      <ThemeToggle />
      <LoginButton />
    </header>
  )
}
