import Link from 'next/link'
import React from 'react'

export default function Sidebar(){
  return (
    <aside className="w-64 bg-white/3 p-4 min-h-screen">
      <div className="mb-6">
        <h1 className="text-xl font-bold">NovaMind Studio</h1>
        <p className="text-sm">AI Video Studio</p>
      </div>
      <nav className="flex flex-col gap-2">
        <Link href="/"><a className="block p-2 rounded hover:bg-white/5">Home</a></Link>
        <Link href="/dashboard"><a className="block p-2 rounded hover:bg-white/5">Dashboard</a></Link>
        <Link href="/video-generator"><a className="block p-2 rounded hover:bg-white/5">Video Generator</a></Link>
        <Link href="/chatbot"><a className="block p-2 rounded hover:bg-white/5">Chatbot</a></Link>
        <Link href="/tts"><a className="block p-2 rounded hover:bg-white/5">Text-to-Speech</a></Link>
      </nav>
    </aside>
  )
}
