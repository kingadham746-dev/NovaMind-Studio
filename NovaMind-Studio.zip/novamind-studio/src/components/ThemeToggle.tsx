import { useEffect, useState } from 'react'

export default function ThemeToggle(){
  const [theme, setTheme] = useState<'dark'|'light'>(() => (typeof window !== 'undefined' && document.documentElement.classList.contains('light')) ? 'light' : 'dark')

  useEffect(()=> {
    if (theme === 'light') document.documentElement.classList.add('light')
    else document.documentElement.classList.remove('light')
  }, [theme])

  return (
    <button onClick={()=> setTheme(t => t === 'dark' ? 'light' : 'dark')} className="px-3 py-1 border rounded">
      {theme === 'dark' ? 'Light' : 'Dark'}
    </button>
  )
}
