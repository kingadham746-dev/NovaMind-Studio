import { signIn, signOut, useSession } from 'next-auth/react'

export default function LoginButton(){
  const { data: session } = useSession()
  if (session) {
    return (
      <div className="flex items-center gap-2">
        <span>{session.user?.name}</span>
        <button onClick={() => signOut()} className="px-3 py-1 border rounded">Sign out</button>
      </div>
    )
  }
  return <button onClick={() => signIn('google')} className="px-3 py-1 border rounded">Sign in with Google</button>
}
