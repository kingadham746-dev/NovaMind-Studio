/**
 * Gemini adapter (server-side) for Generative Language API (Gemini 2.5 Pro)
 * Uses google-auth-library to fetch access token from service account.
 */

import { GoogleAuth } from 'google-auth-library'
import fetch from 'node-fetch'

const MODEL = process.env.GEMINI_MODEL || 'models/gemini-2.5-pro'

async function getAccessToken(): Promise<string> {
  const keyJson = process.env.GOOGLE_SERVICE_ACCOUNT_JSON
  const auth = new GoogleAuth({
    credentials: keyJson ? JSON.parse(keyJson) : undefined,
    scopes: ['https://www.googleapis.com/auth/cloud-platform']
  })
  const client = await auth.getClient()
  const tokenResponse = await client.getAccessToken()
  if (!tokenResponse || !tokenResponse.token) throw new Error('Failed to obtain access token for Google Cloud')
  return tokenResponse.token
}

export async function askGemini(prompt: string, options?: { maxOutputTokens?: number }): Promise<string> {
  const apiKey = process.env.GEMINI_API_KEY
  let bearer = apiKey ? apiKey : undefined

  if (!bearer) {
    bearer = await getAccessToken()
  }

  const url = `https://generativelanguage.googleapis.com/v1/${MODEL}:generateText`
  const payload = {
    prompt: { text: prompt },
    maxOutputTokens: options?.maxOutputTokens || 512,
    temperature: 0.7
  }

  const res = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${bearer}`
    },
    body: JSON.stringify(payload)
  })

  if (!res.ok) {
    const text = await res.text()
    throw new Error('Gemini API error: ' + text)
  }

  const data = await res.json()
  const output = data?.candidates?.[0]?.content?.[0]?.text ||
                 data?.output?.[0]?.content?.[0]?.text ||
                 data?.outputText ||
                 JSON.stringify(data)
  return output
}
