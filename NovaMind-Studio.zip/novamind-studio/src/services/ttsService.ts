/**
 * TTS adapter supporting ElevenLabs (preferred) and Google Cloud TTS fallback.
 * Saves audio to /tmp and returns local path (for production, upload to S3 and return public URL).
 */

import fetch from 'node-fetch'
import fs from 'fs'
import path from 'path'
import { GoogleAuth } from 'google-auth-library'

async function saveBufferToTmp(buf: Buffer, filename: string): Promise<string> {
  const out = path.join('/tmp', filename)
  fs.writeFileSync(out, buf)
  return out
}

export async function generateTTS({ text, voice }: { text: string, voice?: string }): Promise<string> {
  const elevenKey = process.env.ELEVEN_API_KEY
  const elevenVoice = voice || process.env.ELEVEN_VOICE_ID || 'alloy'
  if (elevenKey) {
    const url = `https://api.elevenlabs.io/v1/text-to-speech/${elevenVoice}`
    const resp = await fetch(url, {
      method: 'POST',
      headers: {
        'Accept': 'audio/mpeg',
        'Content-Type': 'application/json',
        'xi-api-key': elevenKey
      },
      body: JSON.stringify({ text, voice: elevenVoice, model: 'eleven_monolingual_v1' })
    })
    if (!resp.ok) {
      const txt = await resp.text()
      throw new Error('ElevenLabs TTS error: ' + txt)
    }
    const arrayBuffer = await resp.arrayBuffer()
    const buf = Buffer.from(arrayBuffer)
    const saved = await saveBufferToTmp(buf, `tts_${Date.now()}.mp3`)
    return saved
  }

  const keyJson = process.env.GOOGLE_SERVICE_ACCOUNT_JSON
  if (keyJson) {
    const auth = new GoogleAuth({ credentials: JSON.parse(keyJson), scopes: ['https://www.googleapis.com/auth/cloud-platform'] })
    const client = await auth.getClient()
    const token = (await client.getAccessToken()).token
    if (!token) throw new Error('Failed to get Google access token for TTS')
    const url = 'https://texttospeech.googleapis.com/v1/text:synthesize'
    const body = { input: { text }, voice: { languageCode: 'en-US', ssmlGender: 'NEUTRAL' }, audioConfig: { audioEncoding: 'MP3' } }
    const r = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` }, body: JSON.stringify(body) })
    if (!r.ok) { const t = await r.text(); throw new Error('Google TTS error: ' + t) }
    const data = await r.json()
    const audioContent = data?.audioContent
    if (!audioContent) throw new Error('No audioContent in TTS response')
    const buf = Buffer.from(audioContent, 'base64')
    const saved = await saveBufferToTmp(buf, `gtts_${Date.now()}.mp3`)
    return saved
  }

  throw new Error('No TTS provider configured (set ELEVEN_API_KEY or GOOGLE_SERVICE_ACCOUNT_JSON)')
}
