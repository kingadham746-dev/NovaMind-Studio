import { Queue } from 'bullmq'
import IORedis from 'ioredis'
import { v4 as uuidv4 } from 'uuid'
import fs from 'fs'
import path from 'path'

const connection = new IORedis(process.env.REDIS_URL || 'redis://127.0.0.1:6379')
const videoQueueName = process.env.VIDEO_QUEUE_NAME || 'video-jobs'
const queue = new Queue(videoQueueName, { connection })

const JOB_DB = path.join('/tmp', 'vm_jobs.json')

function readJobs(){
  try {
    const txt = fs.readFileSync(JOB_DB, 'utf-8')
    return JSON.parse(txt)
  } catch (e) {
    return {}
  }
}
function writeJobs(jobs: any){
  fs.writeFileSync(JOB_DB, JSON.stringify(jobs, null, 2))
}

export async function createVideoJob({ script, duration, model, style, quality, voice }: { script: string, duration: number, model: string, style: string, quality: string, voice: string }) {
  const jobId = 'job_' + Date.now() + '_' + uuidv4().slice(0,8)
  const payload = { jobId, script, duration, model, style, quality, voice }
  await queue.add('render', payload, { attempts: 3, backoff: { type: 'exponential', delay: 2000 } })

  const jobs = readJobs()
  jobs[jobId] = { status: 'queued', payload, createdAt: Date.now() }
  writeJobs(jobs)
  return { id: jobId, status: 'queued' }
}

export async function getJobStatus(jobId: string) {
  const jobs = readJobs()
  if (jobs[jobId]) return { status: jobs[jobId].status, resultUrl: jobs[jobId].resultUrl }
  return { status: 'unknown' }
}

export function updateJobStatus(jobId: string, info: any){
  const jobs = readJobs()
  jobs[jobId] = { ...(jobs[jobId] || {}), ...info }
  writeJobs(jobs)
}
