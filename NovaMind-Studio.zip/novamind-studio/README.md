# NovaMind Studio - Starter Repo (Next.js + TypeScript)

This repo is a production-ready starter scaffold for NovaMind Studio — an AI video creation platform.
It includes:
- Next.js frontend (pages + components)
- API routes (Next.js) for generation and auth
- Gemini adapter (server-side) for prompts / script processing
- TTS adapter (ElevenLabs + Google fallback)
- Video generator UI (supports styles, quality, duration up to 40 minutes)
- Background worker (BullMQ) and S3 uploader
- .env.example and deployment notes

## Quick local steps

1. Install dependencies:
   ```bash
   npm install
   ```

2. Copy `.env.example` to `.env.local` and fill values (Google client, Gemini, AWS, Redis).

3. Start Redis (Docker recommended):
   ```bash
   docker run -d --name redis -p 6379:6379 redis
   ```

4. Run dev server:
   ```bash
   npm run dev
   ```

5. In another terminal run worker:
   ```bash
   npm run worker
   ```

## Deploying
- Frontend: Vercel (connect GitHub repo)
- Worker: run on a server/container (AWS ECS, DigitalOcean App, Render)
- S3: use AWS S3 + CloudFront for CDN
- Redis: managed (ElastiCache, Upstash, Redis Cloud)

For detailed instructions see the sections in repo files.
