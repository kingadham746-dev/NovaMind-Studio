/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  experimental: { appDir: false },
  images: { domains: ['cdn.example.com'] }
}
module.exports = nextConfig
